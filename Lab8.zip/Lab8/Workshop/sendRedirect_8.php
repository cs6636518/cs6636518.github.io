<?php include "connect.php" ?>

<?php
$stmt = $pdo->prepare("INSERT INTO member VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bindParam(1, $_POST["username"]);
$stmt->bindParam(2, $_POST["password"]);
$stmt->bindParam(3, $_POST["name"]);
$stmt->bindParam(4, $_POST["address"]);
$stmt->bindParam(5, $_POST["mobile"]);
$stmt->bindParam(6, $_POST["email"]);

$stmt->execute(); // เริ่มเพิ่มข้อมูล
$username = $_POST["username"];

// header คือฟังก์ชันที่จัดการส่งข้อมูลไปยังไฟล์ที่กำหนด (send redirect)
// ในที่นี้ ให้เปิดเว็บหน้า detail_member.php พร้อมกับส่ง username แนบไปกับ URL
header("location: member_detail_5.php?username=" . $username);
?>